#!/usr/bin/env python
import sys,urllib2,getpass,subprocess,os,string

sxunuser = "XXXXXXXXXXXX@GDPF.XY"
sxunpass = "XXXXXX"
class TerminalPassword(urllib2.HTTPPasswordMgr):
	def find_user_password(self, realm, authuri):
		retval = urllib2.HTTPPasswordMgr.find_user_password(self, realm, authuri)
		if retval[0] == None and retval[1] == None:
			username = "admin"
			password = "admin"
			return (username, password)
		else:
			return retval
p = subprocess.Popen(["./getNetkeeper" , sxunuser , sxunpass], stdin = subprocess.PIPE, stdout = subprocess.PIPE,stderr = subprocess.PIPE,shell = False)
routeurl="http://192.168.1.1/userRpm/PPPoECfgRpm.htm?wan=0&wantype=2&acc=%0D%0A"+p.stdout.read()+"&psw=054656&confirm=054656&specialDial=100&SecType=0&sta_ip=0.0.0.0&sta_mask=0.0.0.0&linktype=4&waittime=0&Connect=%C1%AC+%BD%D3"

req = urllib2.Request(routeurl);
opener = urllib2.build_opener(urllib2.HTTPBasicAuthHandler(TerminalPassword()))
fd = opener.open(req)

